# Panduan Instalasi Aplikasi SIPADU

## Kebutuhan:
- PHP 8.2+
- Composer
- PostgreSQL
- Redis
- Docker (opsional)

## Langkah Cepat:
1. `composer install`
2. Duplikat file `.env.example` menjadi `.env`
3. Jalankan `php spark serve` di folder `backend`

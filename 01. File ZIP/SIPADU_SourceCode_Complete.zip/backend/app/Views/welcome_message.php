<!DOCTYPE html>
<html>
<head>
    <title>Selamat Datang di SIPADU</title>
</head>
<body>
    <h1>Aplikasi SIPADU siap dijalankan 🚀</h1>
</body>
</html>
